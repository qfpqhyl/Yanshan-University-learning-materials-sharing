### 优先级判断

通过对PI8的优先级设定，其功能为实现两个灯随按钮的交替亮灭。

```c
	NVIC_InitStructure8.NVIC_IRQChannelPreemptionPriority = 0; /*主优先级 0~1级*/
	NVIC_InitStructure8.NVIC_IRQChannelSubPriority = 0; /*子优先级 0~7级*/
```

通过对PC13优先级的设定，其功能为实现两个灯随时间的交替闪烁。

```c
	NVIC_InitStructure13.NVIC_IRQChannelPreemptionPriority = 0; /*主优先级 0~1级*/
	NVIC_InitStructure13.NVIC_IRQChannelSubPriority = 1; /*子优先级 0~7级*/
```

按下K1后观察到现象以后继续按下K2，可以看到K2的现象正常发生，但再次摁下K1，无法跳回到其现象，说明其优先级小于K2。