/*
*****************************************************
*
*  NVIC Head File
*  author��Tian Bosong
*  directions��NVIC�жϿ⺯��ͷ�ļ�
*
*****************************************************
*/

#ifndef __NVIC_H
#define __NVIC_H
#endif /* __NVIC_H */

#include "stm32f4xx.h"

void NvicCfg(void);
