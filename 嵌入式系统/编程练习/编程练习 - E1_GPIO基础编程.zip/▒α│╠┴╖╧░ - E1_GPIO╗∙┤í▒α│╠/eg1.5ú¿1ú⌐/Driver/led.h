/*
*****************************************************
*
*  led head file
*  author��Tian Bosong
*  directions��led�⺯�����
*
*****************************************************
*/

#ifndef __LED_H
#define __LED_H
#endif /* __LED_H */

#include "stm32f4xx.h"

// ����LEDö������
typedef enum
{
	LED1 = 1,
	LED2 = 2,
	LED3 = 3,
	LED4 = 4,
}Led_t;

// LED�˿ڶ���
#define LED1_PORT GPIOI
#define LED1_PIN  GPIO_Pin_10
#define LED1_RCC  RCC_AHB1Periph_GPIOI

#define LED2_PORT GPIOF
#define LED2_PIN  GPIO_Pin_7
#define LED2_RCC  RCC_AHB1Periph_GPIOF

#define LED3_PORT GPIOF
#define LED3_PIN  GPIO_Pin_8
#define LED3_RCC  RCC_AHB1Periph_GPIOF

#define LED4_PORT GPIOC
#define LED4_PIN  GPIO_Pin_2
#define LED4_RCC  RCC_AHB1Periph_GPIOC

// ��������
void LED_Init(Led_t);
void LED_On(Led_t);
void LED_Off(Led_t);
void Led_Toggle(Led_t);
