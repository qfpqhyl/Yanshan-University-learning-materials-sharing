/*
*****************************************************
*
*  eg1.5��1��
*  author��Tian Bosong
*  directions��examples, achieve Button control the light status
*
*****************************************************
*/
#include "stm32f4xx.h"
#include "led.h"
#include "key.h"

int main()
{
	//LED��KEY�˿ڳ�ʼ��
	LED_Init(LED1);
	KEY_Init(KEY1);
	//����LED
	LED_On(LED1);
	//ɨ�谴��
	while(1){
		if(KEY_Scan(KEY1) == 1){
			Led_Toggle(LED1);	
		}
	}
}
