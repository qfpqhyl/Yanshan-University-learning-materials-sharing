/*
*****************************************************
*
*  led Source file
*  author��Tian Bosong
*  directions��key�⺯�����
*
*****************************************************
*/

#ifndef __KEY_H
#define __KEY_H
#endif /* __KEY_H */

#include "stm32f4xx.h"

//����KEYö������
typedef enum
{ 
	Key_No = 0,
	KEY1 = 1,
	KEY2 = 2,
	KEY3 = 3,
}Key_t;

// �����˿ڶ���
#define KEY1_PORT GPIOI
#define KEY1_PIN  GPIO_Pin_8
#define KEY1_RCC  RCC_AHB1Periph_GPIOI

#define KEY2_PORT GPIOC
#define KEY2_PIN  GPIO_Pin_13
#define KEY2_RCC  RCC_AHB1Periph_GPIOC

#define KEY3_PORT GPIOI
#define KEY3_PIN  GPIO_Pin_11
#define KEY3_RCC  RCC_AHB1Periph_GPIOI

// ��������
void KEY_Init(Key_t);
int KEY_Scan(Key_t); 
void delay_us(uint32_t delay_us);
void delay_ms(uint16_t delay_ms);
