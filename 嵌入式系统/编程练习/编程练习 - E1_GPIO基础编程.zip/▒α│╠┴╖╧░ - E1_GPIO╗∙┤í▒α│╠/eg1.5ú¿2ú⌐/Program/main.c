/*
*****************************************************
*
*  eg1.5��1��
*  author��Tian Bosong
*  directions��examples, achieve Button control the light status
*
*****************************************************
*/
#include "stm32f4xx.h"
#include "led.h"
#include "key.h"

int main()
{
	//LED��KEY�˿ڳ�ʼ��
	LED_Init(LED1);
	LED_Init(LED2);
	KEY_Init(KEY1);
	KEY_Init(KEY2);
	//����LED
	LED_On(LED1);
	LED_On(LED2);
	//ɨ�谴��
	while(1){
		if(KEY_Scan(KEY1) == 1){
			Led_Toggle(LED1);	
			Led_Toggle(LED2);	
		}
		if(KEY_Scan(KEY2) == 1){
			Led_Toggle(LED1);
			Led_Toggle(LED2);				
		}
	}
}
