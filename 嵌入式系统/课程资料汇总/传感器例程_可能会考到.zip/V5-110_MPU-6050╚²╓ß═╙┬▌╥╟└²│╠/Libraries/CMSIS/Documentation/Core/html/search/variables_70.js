var searchData=
[
  ['pcsr',['PCSR',['../struct_d_w_t___type.html#abc5ae11d98da0ad5531a5e979a3c2ab5',1,'DWT_Type']]],
  ['pfr',['PFR',['../struct_s_c_b___type.html#a3f51c43f952f3799951d0c54e76b0cb7',1,'SCB_Type']]],
  ['port',['PORT',['../struct_i_t_m___type.html#afe056e8c8f8c5519d9b47611fa3a4c46',1,'ITM_Type']]]
];
