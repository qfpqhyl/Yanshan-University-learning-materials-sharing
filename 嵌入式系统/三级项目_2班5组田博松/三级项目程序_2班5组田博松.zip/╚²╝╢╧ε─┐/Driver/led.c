/*
*****************************************************
*
*  led Source file
*  author��Tian Bosong
*  directions��led�⺯�����
*
*****************************************************
*/

#include "led.h"
#include "key.h"

// ��ʼ��LED�˿�
void LED_Init(Led_t LED)
{
	GPIO_InitTypeDef  GPIO_InitStructure;

  //����PINΪ�������
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;        /*��Ϊ�����*/
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;       /*��Ϊ����ģʽ*/
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;    /*IO������ٶ�*/
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;     /*���������費��ʹ��*/

	//ʹ��ʱ�ӣ�ͬʱ��ʼ��Ϊ�ر�״̬
	if(LED == LED1){
		RCC_AHB1PeriphClockCmd(LED1_RCC, ENABLE);
		GPIO_InitStructure.GPIO_Pin = LED1_PIN;
		GPIO_Init(LED1_PORT,&GPIO_InitStructure);
	}
  if(LED == LED2){
		RCC_AHB1PeriphClockCmd(LED2_RCC, ENABLE);	
		GPIO_InitStructure.GPIO_Pin = LED2_PIN;
	  GPIO_Init(LED2_PORT,&GPIO_InitStructure);
	}
  if(LED == LED3){
		RCC_AHB1PeriphClockCmd(LED3_RCC, ENABLE);	
		GPIO_InitStructure.GPIO_Pin = LED3_PIN;
	  GPIO_Init(LED3_PORT,&GPIO_InitStructure);
	}
  if(LED == LED4){
		RCC_AHB1PeriphClockCmd(LED4_RCC, ENABLE);	
		GPIO_InitStructure.GPIO_Pin = LED4_PIN;
		GPIO_Init(LED4_PORT,&GPIO_InitStructure);
	}
}

//����һ��LED
void LED_On(Led_t LED)
{
	if(LED == LED1)
		GPIO_ResetBits(LED1_PORT,LED1_PIN);
  if(LED == LED2)
		GPIO_ResetBits(LED2_PORT,LED2_PIN);
  if(LED == LED3)
		GPIO_ResetBits(LED3_PORT,LED3_PIN);
  if(LED == LED4)
		GPIO_ResetBits(LED4_PORT,LED4_PIN);
}

//�ر�LED
void LED_Off(Led_t LED)
{
	if(LED == LED1)
		GPIO_SetBits(LED1_PORT,LED1_PIN);
  if(LED == LED2)
		GPIO_SetBits(LED2_PORT,LED2_PIN);
  if(LED == LED3)
		GPIO_SetBits(LED3_PORT,LED3_PIN);
  if(LED == LED4)
		GPIO_SetBits(LED4_PORT,LED4_PIN);
}
//�����л�
void LED_Toggle(Led_t LED)
{
	if(LED == LED1)
		GPIO_ToggleBits(LED1_PORT,LED1_PIN);
  if(LED == LED2)
		GPIO_ToggleBits(LED2_PORT,LED2_PIN);
  if(LED == LED3)
		GPIO_ToggleBits(LED3_PORT,LED3_PIN);
  if(LED == LED4)
		GPIO_ToggleBits(LED4_PORT,LED4_PIN);
}
//��ˮ��
void LED_watter(void){
	LED_On(LED1);
	delay_ms(100);
	LED_On(LED2);
	delay_ms(100);
	LED_On(LED3);
	delay_ms(100);
	LED_On(LED4);
	delay_ms(100);
	LED_Off(LED1);
	LED_Off(LED2);
	LED_Off(LED3);
	LED_Off(LED4);
}
