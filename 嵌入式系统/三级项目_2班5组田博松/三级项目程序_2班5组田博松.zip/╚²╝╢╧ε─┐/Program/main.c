/*
************************************************
* �ļ�: main.c
* ����: ������Ŀ
* ���ߣ�BS_Tian
************************************************
*/
 
#include "led.h"
#include "key.h"
#include "beep.h"
#include "NVIC.h"
#include "timer.h"
#include "uart.h"
#include "font.h"
#include "oled.h"
#include "mpu6050.h"
#include "step.h"	
#include "global.h"

//main program
int main(void) 
{  
	uint8_t i;
	//�����жϱ�־λ
	reset_flag = 0;
	//����һ�����������ڴ洢��ǰ�ļ��ٶ�����
  MPU6050Data_t current_data;
  //����һ�����������ڴ洢��ǰ�Ĳ���
  uint32_t current_step_count;
	uint32_t page = 0;
  double step_speed;
	int digit, decimal1, decimal2;
	double step_Calories;
	int minutes;
	int seconds;
	int wendu_1;
	//����һ�����������ڴ���Ŀ�경��
	uint32_t Target_step_count = 10;
	uint32_t body_weight = 40;
	//�����ʼ��	
	LED_Init(LED1);
	LED_Init(LED2);
	LED_Init(LED3);
	LED_Init(LED4);
	KEY_Init(KEY1);
	KEY_Init(KEY2);
	KEY_Init(KEY3);
	UartInit();
	OledInit(); 
	MPU6050Init();
	BEEP_Init();
	//�ж�ϵͳ��ʼ��
	NvicCfg();
	KeyExtiCfg();
	
	while(1)
	{
		OledClear();
		Oled_display_Chinese();
		if(KEY_Scan(KEY2)){
			Target_step_count = Target_step_count + 10;
			if(Target_step_count >= 100){
				Target_step_count = 100;
			}
			if(KEY_Scan(KEY3)){
				break;			
			}
		}
		if(KEY_Scan(KEY3)){
			Target_step_count = Target_step_count - 10;
			if(Target_step_count <= 0){
				Target_step_count = 10;
			}
			if(KEY_Scan(KEY2)){
				break;			
			}
		}
		// ��ʾĿ��Ĳ���
		if (Target_step_count >= 10000)
		OledShowFont8X16 (80, 0, Decimal+ 16 * (Target_step_count /10000 %10) ); //��λ
		if (Target_step_count >= 1000)
		OledShowFont8X16 (88, 0, Decimal+ 16 * (Target_step_count /1000 %10) ); //ǧλ
		if (Target_step_count >= 100)
		OledShowFont8X16 (96, 0, Decimal+ 16 * (Target_step_count /100 %10) ); //��λ
		if (Target_step_count >= 10)
		OledShowFont8X16 (104, 0, Decimal+ 16 * (Target_step_count /10 %10) ); //ʮλ
		OledShowFont8X16 (112, 0, Decimal+ 16 * (Target_step_count /1 %10) ); //��λ
		delay_ms(100);
	}
	Tim3Init();
	while(1)
	{
		OledClear();
		Oled_display_Chinese_page1();
		if(KEY_Scan(KEY2)){
			body_weight = body_weight + 5;
			if(body_weight >= 100){
				body_weight = 100;
			}
			if(KEY_Scan(KEY3)){
				break;			
			}
		}
		if(KEY_Scan(KEY3)){
			body_weight = body_weight - 5;
			if(body_weight <= 40){
				body_weight = 40;
			}
			if(KEY_Scan(KEY2)){
				break;			
			}
		}
		// ��ʾ��ǰ����
		if (body_weight >= 100)
		OledShowFont8X16 (88, 0, Decimal+ 16 * (body_weight /100 %10) ); //��λ
		if (body_weight >= 10)
		OledShowFont8X16 (96, 0, Decimal+ 16 * (body_weight /10 %10) ); //ʮλ
		OledShowFont8X16 (104, 0, Decimal+ 16 * (body_weight /1 %10) ); //��λ
		//��ʾ��ǰʱ��
		minutes = get_system_time() / 60000; // ���������
		seconds = (get_system_time() % 60000) / 1000; // ��������
		OledShowFont8X16 (80, 2, Decimal+ 16 * (minutes /10 %10) ); //ʮλ
		OledShowFont8X16 (88, 2, Decimal+ 16 * (minutes /1 %10) ); //��λ
		OledShowFont16X16 (96, 2, maohao ); //��λ
		OledShowFont8X16 (104, 2, Decimal+ 16 * (seconds /10 %10) ); //ʮλ
		OledShowFont8X16 (112, 2, Decimal+ 16 * (seconds /1 %10) ); //��λ
		//��ʾ��ǰ����
		current_data = read_MPU6050_data();
		wendu_1 = current_data.TempValue;
		if (wendu_1 >= 10)
		OledShowFont8X16 (88, 4, Decimal+ 16 * (wendu_1 /10 %10) ); //ʮλ
		OledShowFont8X16 (96, 4, Decimal+ 16 * (wendu_1 /1 %10) ); //��λ
		OledShowFont16X16(104,4,wendu);
		OledShowFont8X16(120,4,wendu+32);
		delay_ms(100);
	}
	//��֤ϵͳʱ���ڵ��경��Ŀ���ʼ
	Tim3Init();
	while (1)
	{
		if(KEY_Scan(KEY2)){
			page = 0;
			if(KEY_Scan(KEY3)){
				page = 2;
			}
		}
		if(KEY_Scan(KEY3)){
			page = 1;
			if(KEY_Scan(KEY2)){
				page = 2;
			}
		}
		if(page == 0){
			OledClear();
			Oled_display_Chinese();
			// ��ʾĿ��Ĳ���
			if (Target_step_count >= 10000)
			OledShowFont8X16 (80, 0, Decimal+ 16 * (Target_step_count /10000 %10) ); //��λ
			if (Target_step_count >= 1000)
			OledShowFont8X16 (88, 0, Decimal+ 16 * (Target_step_count /1000 %10) ); //ǧλ
			if (Target_step_count >= 100)
			OledShowFont8X16 (96, 0, Decimal+ 16 * (Target_step_count /100 %10) ); //��λ
			if (Target_step_count >= 10)
			OledShowFont8X16 (104, 0, Decimal+ 16 * (Target_step_count /10 %10) ); //ʮλ
			OledShowFont8X16 (112, 0, Decimal+ 16 * (Target_step_count /1 %10) ); //��λ
			delay_ms(100);
			// ��ȡ��ǰ�ļ��ٶ�����
			current_data = read_MPU6050_data();
			// ��Ⲣ���²���
			update_step_countdynamic(current_data);
			// ��ȡ��ǰ�Ĳ���
			current_step_count = get_step_count();
			// ��ʾ��ǰ�Ĳ��������紮�ڣ�LCD��
			if (current_step_count >= 10000)
			OledShowFont8X16 (80, 2, Decimal+ 16 * (current_step_count /10000 %10) ); //��λ
			if (current_step_count >= 1000)
			OledShowFont8X16 (88, 2, Decimal+ 16 * (current_step_count /1000 %10) ); //ǧλ
			if (current_step_count >= 100)
			OledShowFont8X16 (96, 2, Decimal+ 16 * (current_step_count /100 %10) ); //��λ
			if (current_step_count >= 10)
			OledShowFont8X16 (104, 2, Decimal+ 16 * (current_step_count /10 %10) ); //ʮλ
			OledShowFont8X16 (112, 2, Decimal+ 16 * (current_step_count /1 %10) ); //��λ
			if(current_step_count > Target_step_count){
				for(i = 0;i < 20; i++){
					BEEP_Switch(1);
					LED_watter();
					delay_ms(500);
					if(KEY_Scan(KEY1) == 0){
						BEEP_Switch(0); 
						break;
					}
				}
			}
			//��ǰ����
			uint32_t time;
			time = get_system_time();
			step_speed = current_step_count*0.65/time*1000;
			digit = (int)step_speed % 10;
			decimal1 = (int)(step_speed * 10) % 10;
			OledShowFont8X16 (80, 4, Decimal + 16 * digit); //��λ
			OledShowFont8X16 (88, 4, dot); //��λ
			OledShowFont8X16 (96, 4, Decimal + 16 * decimal1); //С��
			for(i = 0;i < 3;i++){
				OledShowFont8X16 (104 + 8*i, 4, m_s + 16 * i); //��λ
			}
			//��·��
			step_Calories =  step_speed * 3.6 * body_weight * time/1000/3600;
			digit = (int)step_Calories % 10;
			decimal1 = (int)(step_Calories * 10) % 10;
			decimal2 = (int)(step_Calories * 100) % 10;
			OledShowFont8X16 (80, 6, Decimal + 16 * digit); //��λ
			OledShowFont8X16 (88, 6, dot); //��λ
			OledShowFont8X16 (96, 6, Decimal + 16 * decimal1); //С��
			OledShowFont8X16 (104, 6, Decimal + 16 * decimal2); //С��
			OledShowFont8X16 (112, 6, J); //С��
			delay_ms(100);
		}
		if(page == 1){
			OledClear();
			Oled_display_Chinese_page1();
			// ��ʾ��ǰ����
			if (body_weight >= 100)
			OledShowFont8X16 (88, 0, Decimal+ 16 * (body_weight /100 %10) ); //��λ
			if (body_weight >= 10)
			OledShowFont8X16 (96, 0, Decimal+ 16 * (body_weight /10 %10) ); //ʮλ
			OledShowFont8X16 (104, 0, Decimal+ 16 * (body_weight /1 %10) ); //��λ
			//��ʾ��ǰʱ��
			minutes = get_system_time() / 60000; // ���������
			seconds = (get_system_time() % 60000) / 1000; // ��������
			OledShowFont8X16 (80, 2, Decimal+ 16 * (minutes /10 %10) ); //ʮλ
			OledShowFont8X16 (88, 2, Decimal+ 16 * (minutes /1 %10) ); //��λ
			OledShowFont16X16 (96, 2, maohao ); //��λ
			OledShowFont8X16 (104, 2, Decimal+ 16 * (seconds /10 %10) ); //ʮλ
			OledShowFont8X16 (112, 2, Decimal+ 16 * (seconds /1 %10) ); //��λ
			//��ʾ��ǰ����
			current_data = read_MPU6050_data();
			wendu_1 = current_data.TempValue;
			if (wendu_1 >= 10)
			OledShowFont8X16 (88, 4, Decimal+ 16 * (wendu_1 /10 %10) ); //ʮλ
			OledShowFont8X16 (96, 4, Decimal+ 16 * (wendu_1 /1 %10) ); //��λ
			OledShowFont16X16(104,4,wendu);
			OledShowFont8X16(120,4,wendu+32);
			delay_ms(100);
		}
	}
}
