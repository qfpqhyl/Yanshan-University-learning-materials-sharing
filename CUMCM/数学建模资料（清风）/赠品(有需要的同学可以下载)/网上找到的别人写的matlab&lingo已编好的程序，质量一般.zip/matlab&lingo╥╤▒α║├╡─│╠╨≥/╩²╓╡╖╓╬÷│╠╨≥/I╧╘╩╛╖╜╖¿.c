#include <stdio.h>

#define HEIGHT 17

int main(void)
{

	int i=0;
	printf("\n\nIIIIIII\n");
	while (i<HEIGHT)
	{
		printf("  III\n");
		i++;
    }
	printf("IIIIIII\n\n\n");

	return 0;
}
