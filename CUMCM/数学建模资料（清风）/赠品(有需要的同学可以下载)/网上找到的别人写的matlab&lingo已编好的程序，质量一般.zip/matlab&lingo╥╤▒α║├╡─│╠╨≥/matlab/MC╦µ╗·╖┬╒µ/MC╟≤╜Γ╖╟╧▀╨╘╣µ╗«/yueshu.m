function y=yueshu(x)
if abs(3*x(1)+x(2)-10)<=0.5
y=1;
else
y=0;
end