function z=f(x,y)
z=y-2*x/y;