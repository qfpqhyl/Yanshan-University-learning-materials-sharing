function y=f(x)          
if x==1
    y=2;
end
if x==2
    y=3;
end
if x==3
    y=4;
end
if x==4
    y=1;
end