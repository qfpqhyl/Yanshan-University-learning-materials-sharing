close all;clear all;clc
f1=imread('text1.jpg');
grayImage = double(rgb2gray(f1));
im1=double(f1(:,:,1));
im2=double(f1(:,:,2));
im3=double(f1(:,:,3));
[im11,s11,s12]=removelight(im1);
[im22,s21,s22]=removelight(im2);
[im33,s31,s32]=removelight(im3);
im(:,:,1)=im11;
im(:,:,2)=im22;
im(:,:,3)=im33;
standard1=(s11+s21+s31)/3;
standard2=(s12+s22+s32)/3;
figure;
subplot(1,2,1);
imshow(im);
imwrite(im,'res1.jpg');
title("去光影后");
subplot(1,2,2);
imshow(f1);
title("原图");
disp("原图的指标为:");disp(standard1);
disp("去光影后指标:");disp(standard2);

function [newt,p1,p2] = removelight(image)
meangray=mean(mean(image))/255;%计算图像平均灰度值，注意在0-1内
[height, width] = size(image);% 获取输入图像的大小
% 创建一个黑底图片
blackImage = zeros(height, width);%黑底图片，用来模拟点光源
upleft=image(1:floor(height/2),1:floor(width/2));
downleft=image(height-floor(height/2)+1:end,1:floor(width/2));
upright=image(1:floor(height/2),width-floor(width/2)+1:end);
downright=image(height-floor(height/2)+1:end,width-floor(width/2)+1:end);
%disp(mean(mean(upleft)));disp(mean(mean(downleft)));disp(mean(mean(upright)));disp(mean(mean(downright)));
ul=mean(mean(upleft));
dl=mean(mean(downleft));
ur=mean(mean(upright));
dr=mean(mean(downright));
directions=[ul,dl,ur,dr];
%disp(directions./255);
p1=max((directions)-min(directions))/255;
if p1<=0.15
    p2=p1;
    newt=image./255;
end
if p1>0.15
    
    [~,direction]=max(directions);
    [blackImage] = makelight(direction,height,width,meangray);
    
    
    % figure;
    blackImage=rot90(blackImage,2);
    %imshow(blackImage);%生成光影图片
    img1=double(image)./255;
    maxback=max(max(blackImage));
    t=(1-meangray)/maxback;
    newt=img1-blackImage.*t;  
    newt=newt+0.3*meangray;
    upleft=newt(1:floor(height/2),1:floor(width/2));
    downleft=newt(height-floor(height/2)+1:end,1:floor(width/2));
    upright=newt(1:floor(height/2),width-floor(width/2)+1:end);
    downright=newt(height-floor(height/2)+1:end,width-floor(width/2)+1:end);
    %disp(mean(mean(upleft)));disp(mean(mean(downleft)));disp(mean(mean(upright)));disp(mean(mean(downright)));
    ul=mean(mean(upleft));
    dl=mean(mean(downleft));
    ur=mean(mean(upright));
    dr=mean(mean(downright));
    directionss=[ul,dl,ur,dr];
    p2=max((directionss)-min(directionss))/255;
    
    
    
end
end

function [blackImage] = makelight(direction,height,width,meangray)

if direction==1
    centerX=1;
    centerY=1;
end
if direction==2
    centerX=1;
    centerY=height;
end
if direction==3
    centerX = width;
    centerY = 1;
end
if direction==4
   centerX = width;
   centerY = height; 
end
% 计算圆的半径
radius = min(width,height);
% 设置光强
for i = 1:height
    for j = 1:width
        % 计算当前位置到圆心的距离
        distance = sqrt((j - centerX)^2 + (i - centerY)^2);
        % 根据距离计算光强
        %intensity = (1-meangray) -distance/radius;
        if radius/distance<=1
            intensity = (1-meangray)*distance/radius;
        end
        if radius/distance>1
        intensity =(1-meangray)*distance/radius;
        end
        % 将光强限制在 0 到 1 之间
        intensity = max(0, max(0, intensity));    
        % 设置当前位置的光强
        blackImage(i, j) = intensity;
    end
end
end
