# CUMCM2022Problems_shumo
2022年数模国赛
代码以及实验结果图片
